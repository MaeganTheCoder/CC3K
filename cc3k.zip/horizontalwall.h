#ifndef HORIZONTALWALL_H_
#define HORIZONTALWALL_H_

#include "tile.h"

class HorizontalWall: public Tile {
 public:
  HorizontalWall(Point coordinate);

};

#endif

#ifndef __DIRECTION__
#define __DIRECTION__

enum class Direction { n, s, e, w, ne, nw, se, sw };

#endif

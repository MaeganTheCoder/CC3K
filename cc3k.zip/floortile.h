#ifndef FLOORTILE_H_
#define FLOORTILE_H_

#include "tile.h"

class FloorTile: public Tile {
 public:
  FloorTile(Point coordinate);
 
};


#endif

#include "action.h"
#include <string>
using namespace std;

Action::~Action() {

}

string Action::getMessage() {
  return message;
}

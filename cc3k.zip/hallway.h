#ifndef HALLWAY_H_
#define HALLWAY_H_

#include "tile.h"

class Hallway: public Tile {
 public:
  Hallway(Point coordinate);

};

#endif

#ifndef VERTICALWALL_H_
#define VERTICALWALL_H_

#include "tile.h"

class VerticalWall: public Tile {
 public:
  VerticalWall(Point coordinate);

};

#endif

#ifndef DOOR_H_
#define DOOR_H_

#include "tile.h"

class Door: public Tile {
 public:
  Door(Point coordinate);

};

#endif

#ifndef BLANK_H_
#define BLANK_H_

#include "tile.h"

class Blank: public Tile {
 public:
  Blank(Point coordinate);

};

#endif
